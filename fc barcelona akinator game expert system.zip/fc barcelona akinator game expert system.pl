akinator:-
write('Do you want to play? Then think about any current Fc Barcelona player'),read(Input),Input='y',question1.

question1:- write('What is the nationality of your player?Choose from 1/argentina 2/spain 3/germany 4/brazil 5/france 6/ghana 7/croatia 8/belgium 9/uraguay
 10/chile 11/netherlands 12/portugal'),read(Input),(Input='argentina'->question2;Input='spain'->question3;Input='germany'->question4;Input='brazil'->question27
;Input='france'->question28;Input='ghana'->question29;Input='croatia'->question30;Input='belgium'->question31;Input='uraguay'->question32;Input='chile'->question33
;Input='netherlands'->question34;Input='portugal'->question35;questionx).

question2:-write('What is the position of your player?'),read(Input),(Input='striker'->question5;Input='defender'->question6;Input='goalkeeper'->question7
;Input='winger'->question8;Input='midfielder'->question9;questionx).
questionx:-write('Wrong input, play again'),akinator.

question5:-write('Sorry there is currently no argentinian striker in Fc Barcelona squad').
question6:-write('Sorry there is currently no argentinian defender in Fc Barcelona squad').
question7:-write('Sorry there is currently no argentinian goalkeeper in Fc Barcelona squad').
question8:-write('Is it Leo Messi?'),read(Input),Input='yes'->write('We are always right you know');write('You are lying because we are always right').
question9:-write('Sorry there is currently no argentinian midfielder in Fc Barcelona squad').

question3:-write('What is the position of your player?'),read(Input),(Input='striker'->question10;Input='defender'->question11;Input='goalkeeper'->question12
;Input='winger'->question13;Input='midfielder'->question14;questionx).

question10:-write('Sorry there is currently no spanish striker in Fc Barcelona squad').
question11:-write('Has your player ever played on any position other than defender?'),read(Input),(Input='yes'->question15;question16).
question12:-write('Sorry there is currently no spanish goalkeeper in Fc Barcelona squad').
question13:-write('Sorry there is currently no spanish winger in Fc Barcelona squad').
question14:-write('Has your player ever won the FIFA World Cup?'),read(Input),(Input='yes'->question17;question18).

question15:-write('Has your player ever played for Manchester United?'),read(Input),(Input='yes'->question19;questioon20).
question16:-write('Is your player one of the fastest players in the Barcelona squad?'),read(Input),(Input='yes'->question21;question22).

question21:-write('Is it Jordi Alba?'),read(Input),(Input='yes'->write('We are always right you know');write('You are lying because we are always rigth you know')).
question22:-write('Sorry, no such player exists').

question17:-write('Is it Sergio Busquets?'),read(Input),Input='yes'->write('We are always right you know');write('You are lying because we are always rigth you know').
question18:-write('Was your player part of the treble winning team in 2014/15 season?'),read(Input),Input='yes'->question25;question26.

question25:-write('Is it Sergi Samper?'),read(Input),Input='yes'->write('We are always right you know');write('You are lying because we are always rigth you know').
question26:-write('Is it Carles Alena?'),read(Input),Input='yes'->write('We are always right you know');write('You are lying because we are always rigth you know').

question19:-write('Is it Gerard Pique?'),read(Input),(Input='yes'->write('We are always right you know');write('You are lying because we are always rigth you know')).
question20:-write('Did your player started off as a midfielder?'),read(Input),(Input='yes'->question23;question24).

question23:-write('Is it Sergi Roberto?'),read(Input),(Input='yes'->write('We are always right you know');write('You are lying because we are always rigth you know')).
question24:-write('Sorry, no such player exists').


question4:-write('What is the position of your player?'),read(Input),(Input='striker'->question36;Input='defender'->question37;Input='goalkeeper'->question38
;Input='winger'->question39;Input='midfielder'->question40;questionx).


question36:-write('Sorry there is currently no german striker in Fc Barcelona squad').
question37:-write('Sorry there is currently no german defender in Fc Barcelona squad').
question38:-write('Is it ter stegan?'),read(Input),Input='yes'->write('We are always right you know');write('You are lying because we are always rigth you know').
question39:-write('Sorry there is currently no german winger in Fc Barcelona squad').
question40:-write('Sorry there is currently no german midfielder in Fc Barcelona squad').


question29:-write('What is the position of your player?'),read(Input),(Input='striker'->question41;Input='defender'->question42;Input='goalkeeper'->question43
;Input='winger'->question44;Input='midfielder'->question45;questionx).


question41:-write('Is it Kevin Prince Boateng?'),read(Input),Input='yes'->write('We are always right you know');write('You are lying because we are always rigth you know').
question42:-write('Sorry there is currently no ghanian defender in Fc Barcelona squad').
question43:-write('Sorry there is currently no ghanian goalkeeper in Fc Barcelona squad').
question44:-write('Sorry there is currently no ghanian winger in Fc Barcelona squad').
question45:-write('Sorry there is currently no ghanian midfielder in Fc Barcelona squad').

question35:-write('What is the position of your player?'),read(Input),(Input='striker'->question46;Input='defender'->question47;Input='goalkeeper'->question48
;Input='winger'->question49;Input='midfielder'->question50;questionx).


question46:-write('Sorry there is currently no portugese striker in Fc Barcelona squad').
question47:-write('Is your player a right back defender?'),read(Input),Input='yes'->question51;question52.
question48:-write('Sorry there is currently no portugese goalkeeper in Fc Barcelona squad').
question49:-write('Sorry there is currently no portugese winger in Fc Barcelona squad').
question50:-write('Sorry there is currently no portugese midfielder in Fc Barcelona squad').

question51:-write('Is it Nelson Semedo?'),read(Input),Input='yes'->write('We are always right you know');write('You are lying because we are always rigth you know').
question52:-write('Sorry, no such player exists').

question34:-write('What is the position of your player?'),read(Input),(Input='striker'->question53;Input='defender'->question54;Input='goalkeeper'->question55
;Input='winger'->question56;Input='midfielder'->question57;questionx).

question53:-write('Sorry there is currently no dutch striker in Fc Barcelona squad').
question54:-write('Sorry there is currently no dutch defender in Fc Barcelona squad').
question55:-write('Is it Jasper Cilessen?'),read(Input),Input='yes'->write('We are always right you know');write('You are lying because we are always rigth you know').
question56:-write('Sorry there is currently no dutch winger in Fc Barcelona squad').
question57:-write('Sorry there is currently no dutch midfielder in Fc Barcelona squad').


question33:-write('What is the position of your player?'),read(Input),(Input='striker'->question58;Input='defender'->question59;Input='goalkeeper'->question60
;Input='winger'->question61;Input='midfielder'->question62;questionx).


question58:-write('Sorry there is currently no chilean striker in Fc Barcelona squad').
question59:-write('Sorry there is currently no chilean defender in Fc Barcelona squad').
question60:-write('Sorry there is currently no chilean goalkeeper in Fc Barcelona squad').
question61:-write('Sorry there is currently no chilean winger in Fc Barcelona squad').
question62:-write('Has your player also won the league title with Juventus and Bayern Munich?'),read(Input),Input='yes'->question63;question64.

question63:-write('Is it Arturo Vidal?'),read(Input),Input='yes'->write('We are always right you know');write('You are lying because we are always rigth you know').
question64:-write('Sorry, no such player exists').


question32:-write('What is the position of your player?'),read(Input),(Input='striker'->question65;Input='defender'->question66;Input='goalkeeper'->question67
;Input='winger'->question68;Input='midfielder'->question69;questionx).


question65:-write('Is he one of MSN?'),read(Input),Input='yes'->question70;question71.
question66:-write('Sorry there is currently no uruguayan defender in Fc Barcelona squad').
question67:-write('Sorry there is currently no uruguayan goalkeeper in Fc Barcelona squad').
question68:-write('Sorry there is currently no uruguayan winger in Fc Barcelona squad').
question69:-write('Sorry there is currently no uruguayan midfielder in Fc Barcelona squad').

question70:-write('Is he Luis Suarez?'),read(Input),Input='yes'->write('We are always right you know');write('You are lying because we are always rigth you know').
question71:-write('Sorry, no such player exists').

question31:-write('What is the position of your player?'),read(Input),(Input='striker'->question72;Input='defender'->question73;Input='goalkeeper'->question74
;Input='winger'->question75;Input='midfielder'->question76;questionx).


question72:-write('Sorry there is currently no belgian striker in Fc Barcelona squad').
question73:-write('Is it Thomas Vermaelen'),read(Input),Input='yes'->write('We are always right you know');write('You are lying because we are always rigth you know').
question74:-write('Sorry there is currently no belgian goalkeeper in Fc Barcelona squad').
question75:-write('Sorry there is currently no belgian winger in Fc Barcelona squad').
question76:-write('Sorry there is currently no belgian midfielder in Fc Barcelona squad').


question30:-write('What is the position of your player?'),read(Input),(Input='striker'->question77;Input='defender'->question78;Input='goalkeeper'->question79
;Input='winger'->question80;Input='midfielder'->question81;questionx).


question77:-write('Sorry there is currently no croatian striker in Fc Barcelona squad').
question78:-write('Sorry there is currently no croatian defender in Fc Barcelona squad').
question79:-write('Sorry there is currently no croatian goalkeeper in Fc Barcelona squad').
question80:-write('Sorry there is currently no croatian winger in Fc Barcelona squad').
question81:-write('Was your player part of the runners up team in the FIFA World Cup Finals 2018?'),read(Input),Input='yes'->question82;question83.

question82:-write('Is it Ivan Rakitic?'),Input='yes'->write('We are always right you know');write('You are lying because we are always rigth you know').
question83:-write('Sorry, no such player exists').


question27:-write('What is the position of your player?'),read(Input),(Input='striker'->question84;Input='defender'->question85;Input='goalkeeper'->question86
;Input='winger'->question87;Input='midfielder'->question88;questionx).


question84:-write('Sorry there is currently no brazilian striker in Fc Barcelona squad').
question85:-write('Sorry there is currently no brazilian defender in Fc Barcelona squad').
question86:-write('Sorry there is currently no brazilian goalkeeper in Fc Barcelona squad').
question87:-write('Is this your players first season at the club?'),read(Input),Input='yes'->question89;question90.
question88:-write('Does your players brother play for Spanish National Team?'),read(Input),Input='yes'->question91;question92.

question89:-write('Is it Malcom?'),read(Input),Input='yes'->write('We are always right you know');write('You are lying because we are always rigth you know').
question90:-write('Sorry, no such player exists').

question91:-write('Is it Rafinha?'),read(Input),Input='yes'->write('We are always right you know');write('You are lying because we are always rigth you know').
question92:-write('Has your player ever played for Liverpool?'),read(Input),Input='yes'->question93;question94.

question93:-write('Is it Philippe Coutinho?'),read(Input),Input='yes'->write('We are always right you know');write('You are lying because we are always rigth you know').
question94:-write('Is it Arthur Melo?'),read(Input),Input='yes'->write('We are always right you know');write('You are lying because we are always rigth you know').

question28:-write('What is the position of your player?'),read(Input),(Input='striker'->question95;Input='defender'->question96;Input='goalkeeper'->question97
;Input='winger'->question98;Input='midfielder'->question99;questionx).


question95:-write('Sorry there is currently no french striker in Fc Barcelona squad').
question96:-write('Did your player score the winning goal in the FIFA World Cup 2018 Semi Final vs Belgium?'),read(Input),Input='yes'->question102;question103.
question97:-write('Sorry there is currently no french goalkeeper in Fc Barcelona squad').
question98:-write('Is your player a Muslim?'),read(Input),Input='yes'->question100;question101.
question99:-write('Sorry there is currently no french midfielder in Fc Barcelona squad').

question100:-write('Is it Ousmane Dembele?'),read(Input),Input='yes'->write('We are always right you know');write('You are lying because we are always rigth you know').
question101:-write('Sorry, no such player exists').

question102:-write('Is it Samual Umtiti?'),read(Input),Input='yes'->write('We are always right you know');write('You are lying because we are always rigth you know').
question103:-write('Did your player sign in January 2019 for a free transfer?'),read(Input),Input='yes'->question104;question105.

question104:-write('Is it Jean Clair Todibo?'),Input='yes'->write('We are always right you know');write('You are lying because we are always rigth you know').
question105:-write('Is it Clement Lenglet?'),Input='yes'->write('We are always right you know');write('You are lying because we are always rigth you know').













